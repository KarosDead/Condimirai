#pragma once

#define HTTP_SERVER "185.84.160.53"
#define HTTP_PORT 80

#define TFTP_SERVER "185.84.160.53"
